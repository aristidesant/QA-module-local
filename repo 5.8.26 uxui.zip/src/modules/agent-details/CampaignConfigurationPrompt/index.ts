export { default } from './CampaignConfigurationPrompt';
