import { MarkerType, Position } from '@xyflow/react';
import type { Edge, Node } from '@xyflow/react';
import type { TFunction } from 'i18next';
import { WORKFLOW_NODE_TYPES } from '../nodeTypes';
import { getEdgeWarningLevel } from '../utils/workflowValidation';
import type {
	AgentWorkflow,
	BoolExpr,
	EndNode,
	OverrideAgentNode,
	PhoneNumberTransferNode,
	UpdateStateNode,
	StandaloneAgentNode,
	StartNode,
	ToolNode,
	WorkflowEdge,
	WorkflowNode,
} from '~/models/AgentWorkflowModel';
import type { NodeGroups } from '~/models/CampaignsModel';

const COMPARISON_OPERATOR_LABELS: Partial<Record<BoolExpr['type'], string>> = {
	eq_operator: '==',
	neq_operator: '!=',
	gt_operator: '>',
	gte_operator: '>=',
	lt_operator: '<',
	lte_operator: '<=',
};

const normalizeWorkflowNodeType = (type: string) =>
	type === 'updateState' ? WORKFLOW_NODE_TYPES.UPDATE_STATE : type;

const quoteExpressionString = (value: string) =>
	`"${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;

const formatExpressionValue = (expression: BoolExpr): string | null => {
	switch (expression.type) {
		case 'dynamic_variable':
			return expression.name.trim() || null;
		case 'string_literal':
			return quoteExpressionString(expression.value);
		case 'number_literal':
			return Number.isFinite(expression.value)
				? String(expression.value)
				: null;
		case 'boolean_literal':
			return expression.value ? 'true' : 'false';
		case 'llm': {
			const prompt = expression.prompt.trim();
			return prompt ? `llm(${quoteExpressionString(prompt)})` : null;
		}
		default:
			return null;
	}
};

const formatExpressionLabel = (expression: BoolExpr): string | null => {
	if (expression.type === 'and_operator' || expression.type === 'or_operator') {
		const operator = expression.type === 'and_operator' ? 'AND' : 'OR';
		const children = expression.children
			.map(formatExpressionLabel)
			.filter((label): label is string => Boolean(label));

		if (!children.length) return null;
		return children.length === 1
			? children[0]
			: children.map((label) => `(${label})`).join(` ${operator} `);
	}

	const operator = COMPARISON_OPERATOR_LABELS[expression.type];

	if (operator && 'left' in expression && 'right' in expression) {
		const left = formatExpressionValue(expression.left);
		const right = formatExpressionValue(expression.right);
		return left && right ? `${left} ${operator} ${right}` : null;
	}

	return formatExpressionValue(expression);
};

export const createWorkflowEdgeMarker = (
	orient: 'auto' | 'auto-start-reverse'
) => ({
	type: MarkerType.Arrow,
	width: 12,
	height: 12,
	orient,
	markerUnits: 'strokeWidth',
	color: 'var(--workflow-shell-control-text, var(--mantine-color-gray-6))',
});

export const defaultEdgeOptions = {
	style: {
		strokeWidth: 2,
		stroke: 'var(--workflow-shell-control-text, var(--mantine-color-gray-6))',
		strokeLinecap: 'round',
		strokeLinejoin: 'round',
	},
	type: 'condition',
	markerEnd: createWorkflowEdgeMarker('auto'),
};

export const WORKFLOW_NODE_DRAG_HANDLE_SELECTOR = '.workflowNodeDragHandle';

export const HANDLE_ID_MAP = {
	source: {
		[Position.Top]: 'source-top',
		[Position.Right]: 'source-right',
		[Position.Bottom]: 'source-bottom',
		[Position.Left]: 'source-left',
	},
	target: {
		[Position.Top]: 'target-top',
		[Position.Right]: 'target-right',
		[Position.Bottom]: 'target-bottom',
		[Position.Left]: 'target-left',
	},
} as const;

export type NodeInternalsMap = Map<
	string,
	{
		positionAbsolute?: { x: number; y: number };
		width?: number;
		height?: number;
	}
>;

export const serializeWorkflow = (workflow: AgentWorkflow): string => {
	const sortedNodes = Object.entries(workflow.nodes)
		.sort(([leftId], [rightId]) => leftId.localeCompare(rightId))
		.map(([id, node]) => [id, node]);
	const sortedEdges = Object.entries(workflow.edges)
		.sort(([leftId], [rightId]) => leftId.localeCompare(rightId))
		.map(([id, edge]) => [id, edge]);
	return JSON.stringify({
		prevent_subagent_loops: workflow.prevent_subagent_loops,
		nodes: sortedNodes,
		edges: sortedEdges,
	});
};

/**
 * If a workflow somehow ends up with more than one START node, keep only the
 * connected one (i.e. the one that appears as a source in at least one edge).
 * If none or multiple are connected, keep the first one found.
 */
export const sanitizeStartNodes = (
	nodes: Record<string, WorkflowNode>,
	edges: Record<string, WorkflowEdge>
): Record<string, WorkflowNode> => {
	const startNodeIds = Object.entries(nodes)
		.filter(([, node]) => node.type === WORKFLOW_NODE_TYPES.START)
		.map(([id]) => id);

	if (startNodeIds.length <= 1) return nodes;

	const connectedStartIds = startNodeIds.filter((id) =>
		Object.values(edges).some((edge) => edge.source === id)
	);

	const keepId = connectedStartIds[0] ?? startNodeIds[0];

	const result = { ...nodes };
	startNodeIds.forEach((id) => {
		if (id !== keepId) delete result[id];
	});

	return result;
};

export const buildDefaultWorkflow = (
	prevent_subagent_loops: boolean
): AgentWorkflow => {
	const startNode: StartNode = {
		type: WORKFLOW_NODE_TYPES.START,
		position: { x: 250, y: 50 },
		edge_order: [],
	};
	return {
		prevent_subagent_loops,
		nodes: { start_node: startNode },
		edges: {},
	};
};

export const mapWorkflowToNodes = (
	workflowData: AgentWorkflow,
	t: TFunction,
	nodeGroups?: NodeGroups
): { nodes: Node[]; edges: Edge[] } => {
	const normalizeSubagent = (node: OverrideAgentNode | StandaloneAgentNode) => {
		const legacyPrompt =
			'additional_prompt' in node ? node.additional_prompt : undefined;
		const legacyToolIds =
			'additional_tool_ids' in node ? node.additional_tool_ids : undefined;
		const legacyKnowledgeBaseIds =
			'additional_knowledge_base' in node
				? node.additional_knowledge_base
				: undefined;
		const legacyTransferMessage =
			'transfer_message' in node ? node.transfer_message : undefined;
		const existing = node.subagent;

		const nextSubagent = {
			...existing,
			prompt:
				existing?.prompt ?? legacyPrompt ?? legacyTransferMessage ?? undefined,
			tool_ids: existing?.tool_ids ?? legacyToolIds ?? [],
			knowledge_base_ids:
				existing?.knowledge_base_ids ?? legacyKnowledgeBaseIds ?? [],
		};

		if (
			nextSubagent.prompt ||
			nextSubagent.tool_ids.length > 0 ||
			nextSubagent.knowledge_base_ids.length > 0
		) {
			return nextSubagent;
		}

		return existing;
	};

	const NON_SELECTABLE_TYPES = [
		WORKFLOW_NODE_TYPES.START,
		WORKFLOW_NODE_TYPES.END,
	];

	const sanitizedNodes = sanitizeStartNodes(
		workflowData.nodes,
		workflowData.edges
	);

	// Build child→parent map from the campaign-level nodeGroups
	const childToGroup = new Map<string, string>();
	const safeNodeGroups = nodeGroups ?? {};
	Object.entries(safeNodeGroups).forEach(([groupId, group]) => {
		group.childNodeIds.forEach((childId) => childToGroup.set(childId, groupId));
	});

	// Build React Flow nodes for groups
	const groupReactNodes: Node[] = Object.entries(safeNodeGroups).map(
		([id, group]) => ({
			id,
			type: WORKFLOW_NODE_TYPES.GROUP,
			position: group.position,
			style: {
				...(group.width ? { width: group.width } : {}),
				...(group.height ? { height: group.height } : {}),
			},
			data: {
				type: WORKFLOW_NODE_TYPES.GROUP,
				position: group.position,
				label: group.label ?? '',
				color: group.color ?? '',
				edge_order: [],
			},
			selectable: true,
			focusable: true,
			dragHandle: undefined,
		})
	);

	const mappedNodes = Object.entries(sanitizedNodes).map(([id, node]) => {
		const normalizedNodeType = normalizeWorkflowNodeType(node.type);
		const nodeId =
			normalizedNodeType === WORKFLOW_NODE_TYPES.START ? 'start_node' : id;
		const parentGroupId = childToGroup.get(id);

		return {
			id: nodeId,
			type: normalizedNodeType,
			position: node.position,
			dragHandle: WORKFLOW_NODE_DRAG_HANDLE_SELECTOR,
			selectable: !NON_SELECTABLE_TYPES.includes(normalizedNodeType as any),
			focusable: !NON_SELECTABLE_TYPES.includes(normalizedNodeType as any),
			...(parentGroupId
				? { parentId: parentGroupId, extent: 'parent' as const }
				: {}),
			data: {
				...node,
				type: normalizedNodeType,
				position: node.position,
				edge_order: node.edge_order ?? [],
				...(normalizedNodeType === WORKFLOW_NODE_TYPES.STANDALONE_AGENT ||
				normalizedNodeType === WORKFLOW_NODE_TYPES.OVERRIDE_AGENT
					? {
							subagent: normalizeSubagent(
								node as OverrideAgentNode | StandaloneAgentNode
							),
						}
					: {}),
			},
		};
	});

	// Group nodes must appear before their children in the array
	const sortedNodes = [...groupReactNodes, ...mappedNodes];

	const getConditionLabel = (
		condition?: WorkflowEdge['forward_condition']
	): string | null => {
		if (!condition) return null;
		if ('label' in condition && condition.label) return condition.label;
		if (condition.type === 'llm') {
			return condition.condition?.trim() || null;
		}
		if (condition.type === 'expression') {
			return formatExpressionLabel(condition.expression);
		}
		if (condition.type === 'result') {
			return condition.successful
				? t('form.workflow.edge.results.success', {
						defaultValue: 'Success',
					})
				: t('form.workflow.edge.results.failure', {
						defaultValue: 'Failure',
					});
		}
		return null;
	};

	const getEdgeLabel = (
		edge: WorkflowEdge
	):
		| string
		| {
				forwardLabel: string;
				backwardLabel: string;
		  }
		| null => {
		const sourceNode = workflowData.nodes[edge.source];
		if (sourceNode?.type === WORKFLOW_NODE_TYPES.START) {
			return null;
		}

		const forwardLabel = getConditionLabel(edge.forward_condition);
		const backwardLabel = getConditionLabel(edge.backward_condition);

		if (forwardLabel && backwardLabel) {
			return {
				forwardLabel,
				backwardLabel,
			};
		}

		return forwardLabel || backwardLabel || null;
	};

	const mappedEdges = Object.entries(workflowData.edges)
		.filter(
			([, edge]) => sanitizedNodes[edge.source] && sanitizedNodes[edge.target]
		)
		.map(([id, edge]) => {
			const sourceNode = sanitizedNodes[edge.source];
			const label = getEdgeLabel(edge);

			return {
				id,
				source: edge.source,
				target: edge.target,
				type: 'condition',
				data: {
					label,
					sourceNodeType: sourceNode?.type,
					forward_condition: edge.forward_condition,
					backward_condition: edge.backward_condition,
					warningLevel: getEdgeWarningLevel(id, workflowData),
				},
			};
		});

	return { nodes: sortedNodes, edges: mappedEdges };
};

export interface BuildWorkflowResult {
	workflow: AgentWorkflow;
	nodeGroups: NodeGroups;
}

const normalizeEdgeOrderValue = (value: unknown): string[] =>
	Array.isArray(value)
		? value.filter((edgeId): edgeId is string => typeof edgeId === 'string')
		: [];

const normalizeBuiltWorkflowEdgeOrder = (
	workflow: AgentWorkflow
): AgentWorkflow => {
	const outgoingEdgeIdsBySource = new Map<string, string[]>();

	Object.entries(workflow.edges).forEach(([edgeId, edge]) => {
		const outgoingEdgeIds = outgoingEdgeIdsBySource.get(edge.source) ?? [];
		outgoingEdgeIds.push(edgeId);
		outgoingEdgeIdsBySource.set(edge.source, outgoingEdgeIds);
	});

	const nodes = Object.entries(workflow.nodes).reduce<
		Record<string, WorkflowNode>
	>((result, [nodeId, node]) => {
		const configuredOrder = normalizeEdgeOrderValue(node.edge_order);
		const validConfiguredOrder = configuredOrder.filter(
			(edgeId) => workflow.edges[edgeId]?.source === nodeId
		);
		const outgoingEdgeIds = outgoingEdgeIdsBySource.get(nodeId) ?? [];
		const missingOutgoingEdgeIds = outgoingEdgeIds.filter(
			(edgeId) => !validConfiguredOrder.includes(edgeId)
		);

		result[nodeId] = {
			...node,
			edge_order: [...validConfiguredOrder, ...missingOutgoingEdgeIds],
		} as WorkflowNode;
		return result;
	}, {});

	return {
		...workflow,
		nodes,
	};
};

export const buildWorkflowFromState = (
	currentNodes: Node[],
	currentEdges: Edge[],
	prevent_subagent_loops: boolean
): BuildWorkflowResult => {
	const workflowNodes: Record<string, WorkflowNode> = {};
	const workflowEdges: Record<string, WorkflowEdge> = {};
	const nodeGroups: NodeGroups = {};

	const sortedNodes = [...currentNodes].sort((a, b) =>
		a.id.localeCompare(b.id)
	);
	const sortedEdges = [...currentEdges].sort((a, b) =>
		a.id.localeCompare(b.id)
	);

	// Collect group node IDs → child IDs
	const groupChildMap = new Map<string, string[]>();
	sortedNodes.forEach((node) => {
		if (node.type === WORKFLOW_NODE_TYPES.GROUP) {
			groupChildMap.set(node.id, []);
		}
	});
	sortedNodes.forEach((node) => {
		if (node.parentId && groupChildMap.has(node.parentId)) {
			groupChildMap.get(node.parentId)!.push(node.id);
		}
	});

	sortedNodes.forEach((node) => {
		const data = node.data as Partial<WorkflowNode>;
		const normalizedNodeType = normalizeWorkflowNodeType(
			(node.type || data.type || WORKFLOW_NODE_TYPES.START) as string
		);
		const baseNode = {
			type: normalizedNodeType as WorkflowNode['type'],
			position: node.position,
			edge_order: data.edge_order ?? [],
			label: data.label,
		};

		switch (normalizedNodeType) {
			case WORKFLOW_NODE_TYPES.TOOL: {
				const toolNode: ToolNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.TOOL,
					tools: (data as ToolNode).tools ?? [],
				};
				workflowNodes[node.id] = toolNode;
				break;
			}
			case WORKFLOW_NODE_TYPES.OVERRIDE_AGENT: {
				const subagent = (data as OverrideAgentNode).subagent;
				const additional_prompt =
					(data as OverrideAgentNode).additional_prompt ??
					subagent?.prompt ??
					'';
				const additional_tool_ids =
					(data as OverrideAgentNode).additional_tool_ids ??
					subagent?.tool_ids ??
					[];
				const additional_knowledge_base =
					(data as OverrideAgentNode).additional_knowledge_base ??
					subagent?.knowledge_base_ids ??
					[];
				const overrideNode: OverrideAgentNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.OVERRIDE_AGENT,
					label: baseNode.label || '',
					additional_prompt,
					additional_tool_ids,
					additional_knowledge_base,
					subagent,
					conversation_config:
						(data as OverrideAgentNode).conversation_config ?? {},
				};
				workflowNodes[node.id] = overrideNode;
				break;
			}
			case WORKFLOW_NODE_TYPES.UPDATE_STATE: {
				const updateStateNode: UpdateStateNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.UPDATE_STATE,
					label: baseNode.label ?? '',
					updates: (data as UpdateStateNode).updates ?? [],
				};
				workflowNodes[node.id] = updateStateNode;
				break;
			}
			case WORKFLOW_NODE_TYPES.PHONE_NUMBER: {
				const phoneNode: PhoneNumberTransferNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.PHONE_NUMBER,
					transfer_type:
						(data as PhoneNumberTransferNode).transfer_type ?? 'conference',
					transfer_destination: (data as PhoneNumberTransferNode)
						.transfer_destination ?? {
						type: 'phone',
						phone_number: '',
					},
				};
				workflowNodes[node.id] = phoneNode;
				break;
			}
			case WORKFLOW_NODE_TYPES.STANDALONE_AGENT: {
				const subagent = (data as StandaloneAgentNode).subagent;
				const additional_prompt =
					(data as StandaloneAgentNode).additional_prompt ??
					subagent?.prompt ??
					undefined;
				const additional_tool_ids =
					(data as StandaloneAgentNode).additional_tool_ids ??
					subagent?.tool_ids ??
					[];
				const additional_knowledge_base =
					(data as StandaloneAgentNode).additional_knowledge_base ??
					subagent?.knowledge_base_ids ??
					[];
				const standaloneNode: StandaloneAgentNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.STANDALONE_AGENT,
					agent_id: (data as StandaloneAgentNode).agent_id ?? '',
					node_id: (data as StandaloneAgentNode).node_id ?? null,
					delay_ms: (data as StandaloneAgentNode).delay_ms ?? 0,
					enable_transferred_agent_first_message:
						(data as StandaloneAgentNode)
							.enable_transferred_agent_first_message ?? false,
					transfer_message: (data as StandaloneAgentNode).transfer_message,
					additional_prompt,
					additional_tool_ids,
					additional_knowledge_base,
					subagent,
					conversation_config:
						(data as StandaloneAgentNode).conversation_config ?? {},
				};
				workflowNodes[node.id] = standaloneNode;
				break;
			}
			case WORKFLOW_NODE_TYPES.GROUP: {
				const nodeData = node.data as { label?: string; color?: string };
				nodeGroups[node.id] = {
					label: nodeData.label,
					position: node.position,
					width:
						typeof node.style?.width === 'number'
							? node.style.width
							: undefined,
					height:
						typeof node.style?.height === 'number'
							? node.style.height
							: undefined,
					color: nodeData.color || undefined,
					childNodeIds: groupChildMap.get(node.id) ?? [],
				};
				break;
			}
			case WORKFLOW_NODE_TYPES.END: {
				const endNode: EndNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.END,
				};
				workflowNodes[node.id] = endNode;
				break;
			}
			case WORKFLOW_NODE_TYPES.START:
			default: {
				const startNode: StartNode = {
					...baseNode,
					type: WORKFLOW_NODE_TYPES.START,
				};
				workflowNodes[node.id] = startNode;
				break;
			}
		}
	});

	sortedEdges.forEach((edge) => {
		const data = edge.data as Partial<WorkflowEdge> | undefined;
		workflowEdges[edge.id] = {
			source: edge.source,
			target: edge.target,
			forward_condition: data?.forward_condition ?? {
				type: 'unconditional' as const,
			},
			backward_condition: data?.backward_condition,
		};
	});

	const workflow = normalizeBuiltWorkflowEdgeOrder({
		prevent_subagent_loops,
		nodes: workflowNodes,
		edges: workflowEdges,
	});

	return {
		workflow,
		nodeGroups,
	};
};
