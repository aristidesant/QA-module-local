import React, {
	createContext,
	useCallback,
	useContext,
	useEffect,
	useMemo,
	useState,
} from 'react';
import type {
	BoolExpr,
	ForwardCondition,
	WorkflowEdge,
} from '~/models/AgentWorkflowModel';
import { WORKFLOW_NODE_TYPES, type WorkflowNodeType } from '../../nodeTypes';
import {
	createDefaultExpression,
	normalizeExpressionForSave,
	validateExpression,
} from './ExpressionBuilder/ExpressionBuilder.helpers';

export type ConditionType =
	| 'none'
	| 'unconditional'
	| 'llm'
	| 'result'
	| 'expression';
export type ConditionDirection = 'forward' | 'backward';

export interface ConditionFormState {
	type: ConditionType;
	label?: string;
	llmCondition?: string;
	resultSuccessful?: boolean;
	expression?: BoolExpr;
}

interface EdgeConditionModalContextValue {
	opened: boolean;
	edgeId?: string;
	edge?: WorkflowEdge;
	sourceLabel?: string;
	targetLabel?: string;
	sourceNodeType?: WorkflowNodeType;
	targetNodeType?: WorkflowNodeType;
	activeTab: ConditionDirection | null;
	setActiveTab: React.Dispatch<React.SetStateAction<ConditionDirection | null>>;
	forwardState: ConditionFormState;
	setForwardState: React.Dispatch<React.SetStateAction<ConditionFormState>>;
	backwardState: ConditionFormState;
	setBackwardState: React.Dispatch<React.SetStateAction<ConditionFormState>>;
	isToolEdge: boolean;
	isConditionAllowed: (
		type: ConditionType,
		direction: ConditionDirection
	) => boolean;
	buildCondition: (state: ConditionFormState) => ForwardCondition | undefined;
	canSave: boolean;
	handleSave: () => void;
	onClose: () => void;
}

interface EdgeConditionModalProviderProps {
	opened: boolean;
	edgeId?: string;
	edge?: WorkflowEdge;
	sourceLabel?: string;
	targetLabel?: string;
	sourceNodeType?: WorkflowNodeType;
	targetNodeType?: WorkflowNodeType;
	onClose: () => void;
	onSave: (
		edgeId: string,
		forward_condition?: ForwardCondition,
		backward_condition?: ForwardCondition
	) => void;
	children: React.ReactNode;
}

const EdgeConditionModalContext =
	createContext<EdgeConditionModalContextValue | null>(null);

const statesEqual = (a: ConditionFormState, b: ConditionFormState) =>
	a.type === b.type &&
	a.label === b.label &&
	a.llmCondition === b.llmCondition &&
	a.resultSuccessful === b.resultSuccessful &&
	JSON.stringify(a.expression) === JSON.stringify(b.expression);

export const EdgeConditionModalProvider = ({
	opened,
	edgeId,
	edge,
	sourceLabel,
	targetLabel,
	sourceNodeType,
	targetNodeType,
	onClose,
	onSave,
	children,
}: EdgeConditionModalProviderProps) => {
	const isToolEdge =
		sourceNodeType === WORKFLOW_NODE_TYPES.TOOL ||
		targetNodeType === WORKFLOW_NODE_TYPES.TOOL;

	const isConditionAllowed = useCallback(
		(type: ConditionType, direction: ConditionDirection): boolean => {
			if (type === 'unconditional' || type === 'result') {
				return isToolEdge && direction === 'backward';
			}
			return type === 'none' || type === 'llm' || type === 'expression';
		},
		[isToolEdge]
	);

	const deriveStateFromCondition = useCallback(
		(
			condition: ForwardCondition | undefined,
			direction: ConditionDirection
		): ConditionFormState => {
			if (!condition) {
				return { type: 'none' };
			}
			switch (condition.type) {
				case 'llm':
					return {
						type: 'llm',
						label: condition.label ?? undefined,
						llmCondition: condition.condition,
					};
				case 'result':
					return isConditionAllowed('result', direction)
						? {
								type: 'result',
								resultSuccessful: condition.successful,
							}
						: { type: 'none' };
				case 'unconditional':
					return isConditionAllowed('unconditional', direction)
						? { type: 'unconditional' }
						: { type: 'none' };
				case 'expression':
					return isConditionAllowed('expression', direction)
						? {
								type: 'expression',
								label: condition.label ?? undefined,
								expression: condition.expression,
							}
						: { type: 'none' };
				default:
					return { type: 'none' };
			}
		},
		[isConditionAllowed]
	);

	const [activeTab, setActiveTab] = useState<ConditionDirection | null>(
		'forward'
	);
	const [forwardState, setForwardState] = useState<ConditionFormState>(() =>
		deriveStateFromCondition(edge?.forward_condition, 'forward')
	);
	const [backwardState, setBackwardState] = useState<ConditionFormState>(() =>
		deriveStateFromCondition(edge?.backward_condition, 'backward')
	);

	useEffect(() => {
		if (!opened) return;

		const nextForward = deriveStateFromCondition(
			edge?.forward_condition,
			'forward'
		);
		const nextBackward = deriveStateFromCondition(
			edge?.backward_condition,
			'backward'
		);

		setForwardState((prev) =>
			statesEqual(prev, nextForward) ? prev : nextForward
		);
		setBackwardState((prev) =>
			statesEqual(prev, nextBackward) ? prev : nextBackward
		);
	}, [
		opened,
		edgeId,
		edge?.forward_condition,
		edge?.backward_condition,
		deriveStateFromCondition,
	]);

	useEffect(() => {
		if (!opened) return;
		setActiveTab('forward');
	}, [opened, edgeId]);

	const buildCondition = useCallback(
		(state: ConditionFormState): ForwardCondition | undefined => {
			switch (state.type) {
				case 'none':
					return undefined;
				case 'unconditional':
					return { type: 'unconditional' };
				case 'llm':
					return {
						type: 'llm',
						condition: state.llmCondition || '',
						label: state.label,
					};
				case 'result':
					return {
						type: 'result',
						successful: state.resultSuccessful ?? true,
					};
				case 'expression':
					return {
						type: 'expression',
						expression: normalizeExpressionForSave(
							state.expression ?? createDefaultExpression()
						),
						label: state.label,
					};
				default:
					return undefined;
			}
		},
		[]
	);

	const canSave = useMemo(() => {
		const states = [forwardState, backwardState];
		return states.every(
			(state) =>
				state.type !== 'expression' ||
				validateExpression(state.expression ?? createDefaultExpression())
					.length === 0
		);
	}, [forwardState, backwardState]);

	const handleSave = useCallback(() => {
		if (!edgeId) return;
		if (!canSave) return;

		const forward_condition = buildCondition(forwardState);
		const backward_condition = buildCondition(backwardState);
		onSave(edgeId, forward_condition, backward_condition);
		onClose();
	}, [
		edgeId,
		canSave,
		forwardState,
		backwardState,
		buildCondition,
		onSave,
		onClose,
	]);

	const value = useMemo<EdgeConditionModalContextValue>(
		() => ({
			opened,
			edgeId,
			edge,
			sourceLabel,
			targetLabel,
			sourceNodeType,
			targetNodeType,
			activeTab,
			setActiveTab,
			forwardState,
			setForwardState,
			backwardState,
			setBackwardState,
			isToolEdge,
			isConditionAllowed,
			buildCondition,
			canSave,
			handleSave,
			onClose,
		}),
		[
			opened,
			edgeId,
			edge,
			sourceLabel,
			targetLabel,
			sourceNodeType,
			targetNodeType,
			activeTab,
			forwardState,
			backwardState,
			isToolEdge,
			isConditionAllowed,
			buildCondition,
			canSave,
			handleSave,
			onClose,
		]
	);

	return (
		<EdgeConditionModalContext.Provider value={value}>
			{children}
		</EdgeConditionModalContext.Provider>
	);
};

export const useEdgeConditionModal = () => {
	const context = useContext(EdgeConditionModalContext);
	if (!context) {
		throw new Error(
			'useEdgeConditionModal must be used within EdgeConditionModalProvider'
		);
	}
	return context;
};
