export { default } from './EdgesTab';
