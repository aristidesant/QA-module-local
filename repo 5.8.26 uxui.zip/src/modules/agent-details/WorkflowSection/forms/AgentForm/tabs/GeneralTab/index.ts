export { default } from './GeneralTab';
