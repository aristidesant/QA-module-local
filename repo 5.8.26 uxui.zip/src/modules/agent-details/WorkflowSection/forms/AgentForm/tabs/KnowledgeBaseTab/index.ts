export { default } from './KnowledgeBaseTab';
