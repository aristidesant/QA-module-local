export { default } from './WorkflowNodeLegend';
