export { default } from './AnalyticsVariablesTable';
