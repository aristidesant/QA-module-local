export { default } from './ModuleGuard';
