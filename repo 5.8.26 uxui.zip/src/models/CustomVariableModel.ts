export * from './DataCollectionTemplateModel';
