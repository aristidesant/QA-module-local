export { default } from './dataCollectionTemplateGroupsApi';
