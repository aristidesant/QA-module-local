export { default } from './AppSegmentedControl';
