export { default } from './InlineNotice';
