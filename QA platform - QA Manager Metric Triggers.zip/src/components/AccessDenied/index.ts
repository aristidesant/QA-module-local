export { default } from './AccessDenied';
