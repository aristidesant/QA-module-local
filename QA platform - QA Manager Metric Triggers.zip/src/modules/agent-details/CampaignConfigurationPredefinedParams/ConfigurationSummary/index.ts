export { default } from './ConfigurationSummary';
