export { default } from './CampaignConfigurationPredefinedParams';
